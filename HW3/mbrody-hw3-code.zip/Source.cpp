#include "Graph.h"


int main() {

	Graph graph = Graph();

	//TODO: Implement menu here

	return 0;
}